# EDM CustomApps Infrastructure - Dynamic Tagging Version

## Overview
CloudFormation infrastructure for EDM CustomApps with **comprehensive dynamic tagging** support. All tags are configurable via parameter files.

## Key Features

### ✅ Dynamic Tagging System
- All tags defined in `params/{env}.json`
- Tags automatically applied to all resources
- Environment-specific tag customization
- Supports custom tags per environment

### ✅ Existing VPC Integration
- Uses existing VPC infrastructure
- No VPC creation (avoids SCP restrictions)
- Configurable subnet mapping

### ✅ Multi-Environment Support
- Separate parameter files for dev, qa, prod
- Environment-specific configurations
- Easy promotion between environments

---

## Tag Structure

### Standard Tags (Applied to All Resources)

| Tag Name | Description | Example | Source |
|----------|-------------|---------|--------|
| `Environment` | Deployment environment | `dev`, `qa`, `prod` | Required parameter |
| `Workstream` | Business workstream | `edm` | Required parameter |
| `AppName` | Application name | `customapps` | Required parameter |
| `CostCenter` | Billing cost center | `CC-12345` | Required parameter |
| `Owner` | Team owner | `edm-platform-team` | Required parameter |
| `Project` | Project name | `EDMCustomApps` | Required parameter |
| `ManagedBy` | Management method | `CloudFormation` | Required parameter |

### Automatic Tags (Added by Stack)

| Tag Name | Description | Example |
|----------|-------------|---------|
| `StackName` | CloudFormation stack name | `hq-edm-stack1` |
| `Region` | AWS region | `us-east-1` |
| `Name` | Resource-specific name | `edm-customapps-s3-dev` |

### Optional Custom Tags (Per Environment)

You can add environment-specific tags in the `Tags` section of parameter files:

```json
{
  "Tags": {
    "DeploymentMethod": "CodePipeline",
    "Repository": "edm-customapps-platform-iac",
    "Compliance": "Required",
    "DataClassification": "Internal"
  }
}
```

---

## File Structure

```
updated-templates-v2/
├── buildspec.yml                      # CodeBuild buildspec
├── params/
│   ├── dev.json                       # Development environment
│   ├── qa.json                        # QA environment (template)
│   └── prod.json                      # Production environment (template)
└── templates/
    ├── root.yml                       # Main template with dynamic tags
    ├── s3/
    │   └── buckets.yml               # S3 buckets
    └── secrets/
        └── secrets-params.yml         # Secrets with dynamic tags
```

---

## Parameter File Format

### Example: `params/dev.json`

```json
{
  "Parameters": {
    "Workstream": "edm",
    "AppName": "customapps",
    "Environment": "dev",
    "CostCenter": "CC-12345",
    "Owner": "edm-platform-team",
    "Project": "EDMCustomApps",
    "ManagedBy": "CloudFormation",
    "VpcId": "vpc-07acc586ab2a9bab7",
    "PublicSubnet1Id": "subnet-XXXXX",
    "PublicSubnet2Id": "subnet-YYYYY",
    "PrivateSubnet1Id": "subnet-AAAAA",
    "PrivateSubnet2Id": "subnet-BBBBB",
    "ArtifactoryUsername": "223145047",
    "ArtifactoryPassword": "CHANGE_ME_AFTER_DEPLOYMENT",
    "ArtifactoryUrl": "geaerospace.jfrog.io/streamlit-docker-local-dev",
    "DockerHubUsername": "abdullahmamunge",
    "DockerHubToken": "CHANGE_ME_AFTER_DEPLOYMENT",
    "OIDCClientId": "av-edm-streamlit-app-launcher-dev-2",
    "OIDCClientSecret": "CHANGE_ME_AFTER_DEPLOYMENT"
  },
  "Tags": {
    "Environment": "dev",
    "Workstream": "edm",
    "AppName": "customapps",
    "CostCenter": "CC-12345",
    "Owner": "edm-platform-team",
    "Project": "EDMCustomApps",
    "ManagedBy": "CloudFormation",
    "DeploymentMethod": "CodePipeline",
    "Repository": "edm-customapps-platform-iac",
    "Region": "us-east-1"
  }
}
```

---

## Deployment Instructions

### Step 1: Configure Parameters for Your Environment

**For Development (dev):**
```bash
# Edit params/dev.json
# Update VPC and subnet IDs with your values
# Update secrets placeholders (will change after deployment)
```

**For QA:**
```bash
# Edit params/qa.json  
# Get QA VPC and subnet IDs
# Update QA-specific values
```

**For Production:**
```bash
# Edit params/prod.json
# Get production VPC and subnet IDs
# Update production credentials
# Add compliance tags
```

### Step 2: Customize Tags (Optional)

Add environment-specific tags in the `Tags` section:

```json
"Tags": {
  "YourCustomTag": "YourValue",
  "Department": "Platform Engineering",
  "BusinessUnit": "Aviation"
}
```

### Step 3: Deploy to GitHub

```bash
# Clone your repository
git clone https://github.com/ge-aero/edm-customapps-platform-iac.git
cd edm-customapps-platform-iac

# Copy updated files
cp -r updated-templates-v2/* .

# Commit and push
git add .
git commit -m "Add dynamic tagging and use existing VPC"
git push origin main
```

### Step 4: Clean Up Failed Stacks

```bash
# Delete any existing failed stacks
aws cloudformation delete-stack \
  --stack-name hq-edm-stack-test2 \
  --region us-east-1

# Wait for deletion
aws cloudformation wait stack-delete-complete \
  --stack-name hq-edm-stack-test2 \
  --region us-east-1
```

### Step 5: Deploy via CodePipeline

1. Go to AWS CodePipeline Console
2. Find pipeline: `hq-edm-codepipeline-test1`
3. Click **Release change**
4. Monitor deployment

---

## Verifying Tags

### Check CloudFormation Stack Tags

```bash
aws cloudformation describe-stacks \
  --stack-name hq-edm-stack1 \
  --region us-east-1 \
  --query 'Stacks[0].Tags'
```

### Check Secrets Manager Tags

```bash
aws secretsmanager describe-secret \
  --secret-id av-edm/cicd/streamlit-docker-artifactory \
  --region us-east-1 \
  --query 'Tags'
```

### Check Parameter Store Tags

```bash
aws ssm describe-parameters \
  --parameter-filters "Key=Name,Values=/av-edm/cicd/dockerhub-token" \
  --region us-east-1 \
  --query 'Parameters[0].Tags'
```

### Check S3 Bucket Tags

```bash
aws s3api get-bucket-tagging \
  --bucket hq-edm-customapps-dev-s3-artifacts \
  --region us-east-1
```

---

## Tag Governance

### Best Practices

1. **Always Include Required Tags**
   - Environment
   - Workstream
   - AppName
   - CostCenter
   - Owner
   - Project
   - ManagedBy

2. **Use Consistent Values**
   - `Environment`: lowercase (dev, qa, uat, prod)
   - `CostCenter`: Follow GE Aerospace format
   - `Owner`: Use team name, not individual

3. **Add Compliance Tags for Production**
   ```json
   "Compliance": "Required",
   "DataClassification": "Internal",
   "BackupPolicy": "Daily"
   ```

4. **Use Tags for Cost Tracking**
   - Group by CostCenter
   - Filter by Project
   - Track by Environment

### GE Aerospace Tagging Standards

Follow GE Aerospace cloud governance policies:
- **Cost Center**: Required for all resources
- **Owner**: Must be a valid team identifier
- **Environment**: Must match approved environments
- **Data Classification**: Required for production resources

---

## Multi-Environment Workflow

### Promoting from Dev to QA

```bash
# 1. Test in dev first
# 2. Update qa.json with QA-specific values
# 3. Update CodePipeline to use params/qa.json
# 4. Deploy to QA
```

### Promoting from QA to Prod

```bash
# 1. Validate in QA
# 2. Update prod.json with production values
# 3. Add production-specific tags
# 4. Get change approval (if required)
# 5. Deploy to production
```

---

## Troubleshooting Tags

### Tags Not Appearing on Resources

**Problem**: Tags defined in params file not showing on resources

**Solutions**:
1. Check parameter file JSON syntax
2. Verify tag names don't have typos
3. Ensure tags are passed to nested stacks
4. Check IAM permissions for tagging

### Tag Limit Exceeded

**Problem**: AWS tag limit (50 tags) exceeded

**Solutions**:
1. Remove unnecessary custom tags
2. Consolidate similar tags
3. Use tag values to store multiple pieces of info

### Tags Not Propagating to Nested Resources

**Problem**: Nested stack resources don't have parent tags

**Solutions**:
1. Explicitly pass tags as parameters
2. Add tags in nested templates
3. Use Tag propagation policies (if available)

---

## Cost Allocation

### Setting Up Cost Allocation Tags

1. **AWS Billing Console** → **Cost Allocation Tags**
2. **Activate tags**:
   - CostCenter
   - Environment
   - Project
   - Workstream
3. **Wait 24 hours** for tags to appear in Cost Explorer

### Creating Cost Reports

```bash
# Get costs by environment
aws ce get-cost-and-usage \
  --time-period Start=2026-01-01,End=2026-01-31 \
  --granularity MONTHLY \
  --metrics "BlendedCost" \
  --group-by Type=TAG,Key=Environment

# Get costs by project
aws ce get-cost-and-usage \
  --time-period Start=2026-01-01,End=2026-01-31 \
  --granularity MONTHLY \
  --metrics "BlendedCost" \
  --group-by Type=TAG,Key=Project
```

---

## Support

### Tag-Related Issues
- Cloud Governance Team: For tagging standards
- FinOps Team: For cost allocation tags
- Platform Team: For technical implementation

### Deployment Issues
- See main README for deployment troubleshooting
- Check CloudFormation events for specific errors

---

## Version History

- **v2.1.0** (2026-01-29): Added comprehensive dynamic tagging
- **v2.0.0** (2026-01-29): Updated to use existing VPC
- **v1.0.0** (2026-01-11): Original version with VPC creation
